/* ===== Рынок ИКТ Кыргызстана — логика приложения ===== */
(() => {
  'use strict';

  /* ---------------------------------------------------------
   * 1. Константы и справочники
   * --------------------------------------------------------- */
  const STORAGE_KEY = 'ict-kg-market-v1';

  const CATEGORIES = [
    'Разработка ПО', 'Телекоммуникации', 'Облачные услуги и ЦОД', 'Кибербезопасность',
    'Финтех и платежи', 'E-commerce', 'Аутсорсинг и IT-консалтинг', 'EdTech',
    'Государственные ИТ-решения'
  ];
  const CITIES = ['Бишкек', 'Ош', 'Джалал-Абад', 'Каракол', 'Нарын', 'Талас', 'Токмок', 'Баткен'];
  const STATUSES = ['Активна', 'На модерации', 'Приостановлена'];
  const PRODUCT_TYPES = ['IT-услуга', 'Программное обеспечение', 'Цифровой продукт'];

  const PALETTE = ['#0f9d6e', '#0e8f9a', '#1b6ec2', '#6cc24a', '#37b5c9', '#2f4fa3',
                   '#8bd3a8', '#5aa9e6', '#0b6b57', '#a3d9e6'];

  /* ---------------------------------------------------------
   * 2. Демонстрационные данные (вымышленные!)
   * --------------------------------------------------------- */
  const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 7);

  function seedData() {
    const c = (name, category, city, founded, employees, revenue, services, status = 'Активна') => ({
      id: uid(), demo: true, name, category, city, founded, employees, revenue, services,
      website: '', email: '', phone: '', contact: '', status
    });
    const p = (name, type, company, price, unit, description) => ({
      id: uid(), demo: true, name, type, company, price, unit, description
    });
    const s = (year, marketVolume, gdpShare, exportUsd, employed, internet) => ({
      id: uid(), demo: true, year, marketVolume, gdpShare, exportUsd, employed, internet
    });

    return {
      companies: [
        c('Алатоо Софт', 'Разработка ПО', 'Бишкек', 2014, 85, 142, 'Заказная разработка, мобильные приложения, ERP'),
        c('Ала-Тоо Аутсорс', 'Аутсорсинг и IT-консалтинг', 'Бишкек', 2016, 120, 210, 'Выделенные команды разработчиков, IT-аудит, QA'),
        c('Ысык-Көл Дата', 'Облачные услуги и ЦОД', 'Каракол', 2018, 22, 38, 'Хостинг, VPS, резервное копирование'),
        c('Манас Диджитал', 'Государственные ИТ-решения', 'Бишкек', 2012, 64, 97, 'Электронный документооборот, порталы услуг'),
        c('Тянь-Шань Нет', 'Телекоммуникации', 'Бишкек', 2008, 310, 1150, 'Интернет для дома и бизнеса, корпоративные сети'),
        c('Памир Секьюрити', 'Кибербезопасность', 'Бишкек', 2017, 38, 74, 'Пентест, SOC, обучение сотрудников'),
        c('Сары-Челек Пэй', 'Финтех и платежи', 'Бишкек', 2019, 56, 188, 'Платёжные шлюзы, онлайн-эквайринг, кошельки'),
        c('Ош Тех Хаб', 'Разработка ПО', 'Ош', 2020, 29, 31, 'Веб-разработка, сайты и интернет-магазины под ключ'),
        c('Нур Маркет', 'E-commerce', 'Бишкек', 2018, 74, 265, 'Онлайн-маркетплейс, логистика, витрины продавцов'),
        c('Жеты-Огуз Лаб', 'EdTech', 'Каракол', 2021, 17, 14, 'Онлайн-курсы программирования, платформа обучения'),
        c('Эль-Софт Джалал-Абад', 'Разработка ПО', 'Джалал-Абад', 2019, 21, 19, 'Учётные системы для малого бизнеса'),
        c('Кок-Жар Клауд', 'Облачные услуги и ЦОД', 'Бишкек', 2020, 33, 61, 'Облачное хранилище, аренда серверов, миграция в облако'),
        c('Нарын Смарт', 'Государственные ИТ-решения', 'Нарын', 2022, 12, 9, 'Цифровизация муниципальных услуг', 'На модерации'),
        c('Талас Агро-ИТ', 'Разработка ПО', 'Талас', 2021, 14, 11, 'Мобильные приложения для сельского хозяйства', 'Приостановлена')
      ],
      products: [
        p('Корпоративная CRM «Алатоо CRM»', 'Программное обеспечение', 'Алатоо Софт', 4500, 'сом / мес. за пользователя', 'Учёт клиентов, сделок и задач'),
        p('Разработка мобильного приложения', 'IT-услуга', 'Алатоо Софт', 450000, 'сом / проект', 'Android и iOS, от прототипа до публикации'),
        p('Выделенный разработчик', 'IT-услуга', 'Ала-Тоо Аутсорс', 95000, 'сом / мес.', 'Разработчик в команде заказчика'),
        p('IT-аудит инфраструктуры', 'IT-услуга', 'Ала-Тоо Аутсорс', 120000, 'сом / проект', 'Оценка сетей, серверов и процессов'),
        p('Виртуальный сервер (VPS)', 'IT-услуга', 'Ысык-Көл Дата', 1200, 'сом / мес.', '2 vCPU, 4 ГБ RAM, 60 ГБ SSD'),
        p('Облачное хранилище 1 ТБ', 'Цифровой продукт', 'Кок-Жар Клауд', 2400, 'сом / мес.', 'Хранение и совместный доступ к файлам'),
        p('Система электронного документооборота', 'Программное обеспечение', 'Манас Диджитал', 18000, 'сом / мес.', 'Согласование и подписание документов'),
        p('Домашний интернет 100 Мбит/с', 'IT-услуга', 'Тянь-Шань Нет', 700, 'сом / мес.', 'Безлимитный тариф для дома'),
        p('Тестирование на проникновение', 'IT-услуга', 'Памир Секьюрити', 250000, 'сом / проект', 'Проверка веб-приложений и сетей'),
        p('Антифишинг-платформа', 'Программное обеспечение', 'Памир Секьюрити', 35000, 'сом / мес.', 'Обучение сотрудников и тестовые рассылки'),
        p('Платёжный шлюз для магазинов', 'Цифровой продукт', 'Сары-Челек Пэй', 15000, 'сом / мес.', 'Приём онлайн-платежей на сайте'),
        p('Размещение товара на маркетплейсе', 'Цифровой продукт', 'Нур Маркет', 900, 'сом / мес.', 'Тариф «Базовый» для продавцов'),
        p('Онлайн-курс по программированию', 'Цифровой продукт', 'Жеты-Огуз Лаб', 3500, 'сом / мес.', 'Python и веб-разработка с наставником'),
        p('Приложение для фермеров', 'Программное обеспечение', 'Талас Агро-ИТ', 600, 'сом / мес.', 'Календарь работ и учёт урожая'),
        p('Сайт-визитка под ключ', 'IT-услуга', 'Ош Тех Хаб', 40000, 'сом / проект', 'Дизайн, вёрстка, хостинг на год'),
        p('Учёт для малого бизнеса', 'Программное обеспечение', 'Эль-Софт Джалал-Абад', 1500, 'сом / мес.', 'Склад, касса, отчёты')
      ],
      stats: [
        s(2018, 18.2, 3.1, 62, 14.5, 56),
        s(2019, 20.1, 3.3, 70, 15.2, 60),
        s(2020, 22.4, 3.4, 78, 16.0, 66),
        s(2021, 25.9, 3.6, 95, 17.8, 72),
        s(2022, 29.7, 3.8, 118, 19.5, 76),
        s(2023, 34.0, 4.0, 142, 21.3, 80),
        s(2024, 38.6, 4.2, 168, 23.1, 83),
        s(2025, 43.5, 4.4, 196, 25.0, 85)
      ]
    };
  }

  /* ---------------------------------------------------------
   * 3. Утилиты
   * --------------------------------------------------------- */
  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));
  const esc = v => String(v ?? '').replace(/[&<>"']/g, ch =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));
  const num = v => Number(v) || 0;
  const fmt = (v, digits = 0) => num(v).toLocaleString('ru-RU', { maximumFractionDigits: digits });
  const sum = (arr, key) => arr.reduce((t, x) => t + num(x[key]), 0);
  const demoTag = r => r.demo ? ' <span class="tag tag--demo">демо</span>' : '';

  function groupBy(arr, keyFn) {
    const map = new Map();
    arr.forEach(x => {
      const k = keyFn(x);
      if (!map.has(k)) map.set(k, []);
      map.get(k).push(x);
    });
    return map;
  }

  function toast(message, type = 'ok') {
    const el = document.createElement('div');
    el.className = 'toast' + (type === 'error' ? ' toast--error' : '');
    el.textContent = message;
    $('#toasts').appendChild(el);
    setTimeout(() => el.remove(), 3200);
  }

  /* ---------------------------------------------------------
   * 4. Хранилище (localStorage)
   * --------------------------------------------------------- */
  let state = { companies: [], products: [], stats: [] };

  function loadState() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (parsed && Array.isArray(parsed.companies) && Array.isArray(parsed.products) && Array.isArray(parsed.stats)) {
          state = parsed;
          return;
        }
      }
    } catch (e) { /* повреждённые данные — загружаем демо */ }
    state = seedData();
    saveState();
  }

  function saveState() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch (e) {
      toast('Не удалось сохранить данные в localStorage', 'error');
    }
  }

  /* ---------------------------------------------------------
   * 5. Описание сущностей и полей форм
   * --------------------------------------------------------- */
  const ENTITIES = {
    companies: {
      nameOf: r => r.name,
      addTitle: 'Добавить компанию',
      editTitle: 'Редактировать компанию',
      defaults: () => ({ category: CATEGORIES[0], city: 'Бишкек', founded: new Date().getFullYear(), status: 'Активна' }),
      fields: [
        { key: 'name', label: 'Название компании', type: 'text', required: true, full: true, max: 120 },
        { key: 'category', label: 'Направление деятельности', type: 'select', options: () => CATEGORIES, required: true },
        { key: 'city', label: 'Город', type: 'select', options: () => CITIES, required: true },
        { key: 'founded', label: 'Год основания', type: 'number', required: true, min: 1990, max: new Date().getFullYear() },
        { key: 'employees', label: 'Число сотрудников', type: 'number', min: 0, max: 100000 },
        { key: 'revenue', label: 'Годовая выручка, млн сом', type: 'number', min: 0, step: '0.1' },
        { key: 'status', label: 'Статус', type: 'select', options: () => STATUSES, required: true, onlyModal: true },
        { key: 'services', label: 'Услуги и продукты', type: 'textarea', full: true, max: 400 },
        { key: 'website', label: 'Сайт', type: 'text', format: 'url', placeholder: 'https://…' },
        { key: 'email', label: 'E-mail', type: 'text', format: 'email', placeholder: 'info@company.kg' },
        { key: 'phone', label: 'Телефон', type: 'text', format: 'tel', placeholder: '+996 …' },
        { key: 'contact', label: 'Контактное лицо', type: 'text', max: 100 }
      ]
    },
    products: {
      nameOf: r => r.name,
      addTitle: 'Добавить услугу / продукт',
      editTitle: 'Редактировать услугу / продукт',
      defaults: () => ({ type: PRODUCT_TYPES[0], unit: 'сом / мес.' }),
      fields: [
        { key: 'name', label: 'Название', type: 'text', required: true, full: true, max: 140 },
        { key: 'type', label: 'Тип', type: 'select', options: () => PRODUCT_TYPES, required: true },
        { key: 'company', label: 'Компания-поставщик', type: 'text', required: true, list: () => state.companies.map(x => x.name) },
        { key: 'price', label: 'Цена, сом', type: 'number', required: true, min: 0, step: '0.01' },
        { key: 'unit', label: 'Единица (период)', type: 'text', required: true, max: 60 },
        { key: 'description', label: 'Описание', type: 'textarea', full: true, max: 400 }
      ]
    },
    stats: {
      nameOf: r => 'данные за ' + r.year + ' г.',
      addTitle: 'Добавить показатели за год',
      editTitle: 'Редактировать показатели',
      defaults: () => {
        const years = state.stats.map(x => num(x.year));
        return { year: years.length ? Math.max(...years) + 1 : new Date().getFullYear() };
      },
      fields: [
        { key: 'year', label: 'Год', type: 'number', required: true, min: 2000, max: 2100 },
        { key: 'marketVolume', label: 'Объём рынка ИКТ, млрд сом', type: 'number', required: true, min: 0, step: '0.1' },
        { key: 'gdpShare', label: 'Доля ИКТ в ВВП, %', type: 'number', required: true, min: 0, max: 100, step: '0.1' },
        { key: 'exportUsd', label: 'Экспорт ИКТ-услуг, млн USD', type: 'number', required: true, min: 0, step: '0.1' },
        { key: 'employed', label: 'Занятые в ИКТ, тыс. чел.', type: 'number', required: true, min: 0, step: '0.1' },
        { key: 'internet', label: 'Пользователи интернета, %', type: 'number', required: true, min: 0, max: 100, step: '0.1' }
      ]
    }
  };

  /* ---------------------------------------------------------
   * 6. Генерация и проверка форм
   * --------------------------------------------------------- */
  function fieldHTML(f, value, prefix) {
    const id = `${prefix}_${f.key}`;
    const v = value ?? '';
    let input;
    if (f.type === 'select') {
      input = `<select id="${id}" name="${f.key}">${f.options().map(o =>
        `<option value="${esc(o)}"${o === v ? ' selected' : ''}>${esc(o)}</option>`).join('')}</select>`;
    } else if (f.type === 'textarea') {
      input = `<textarea id="${id}" name="${f.key}" maxlength="${f.max || 500}">${esc(v)}</textarea>`;
    } else {
      const attrs = [
        `type="${f.type === 'number' ? 'number' : 'text'}"`,
        f.min !== undefined ? `min="${f.min}"` : '',
        f.max !== undefined && f.type === 'number' ? `max="${f.max}"` : '',
        f.max !== undefined && f.type !== 'number' ? `maxlength="${f.max}"` : '',
        f.type === 'number' ? `step="${f.step || 1}"` : '',
        f.placeholder ? `placeholder="${esc(f.placeholder)}"` : '',
        f.list ? `list="${id}_list"` : ''
      ].join(' ');
      input = `<input id="${id}" name="${f.key}" ${attrs} value="${esc(v)}">`;
      if (f.list) input += `<datalist id="${id}_list">${f.list().map(o => `<option value="${esc(o)}">`).join('')}</datalist>`;
    }
    return `<div class="field${f.full ? ' full' : ''}" data-field="${f.key}">
      <label for="${id}">${esc(f.label)}${f.required ? ' *' : ''}</label>${input}
      <small class="error"></small></div>`;
  }

  function readForm(form, fields) {
    const values = {};
    fields.forEach(f => {
      const el = form.elements[f.key];
      values[f.key] = el ? el.value.trim() : '';
    });
    return values;
  }

  const FORMATS = {
    url: [/^https?:\/\/[^\s.]+\.\S+$/i, 'Введите адрес вида https://example.kg'],
    email: [/^[^\s@]+@[^\s@]+\.[^\s@]+$/, 'Введите корректный e-mail'],
    tel: [/^[+\d][\d\s()-]{6,19}$/, 'Введите корректный телефон, например +996 555 123456']
  };

  function validate(entity, values, fields, editingId) {
    const errors = {};
    fields.forEach(f => {
      const v = values[f.key];
      if (f.required && v === '') { errors[f.key] = 'Обязательное поле'; return; }
      if (v === '') return;
      if (f.type === 'number') {
        const n = Number(v);
        if (!Number.isFinite(n)) errors[f.key] = 'Введите число';
        else if (f.min !== undefined && n < f.min) errors[f.key] = `Не меньше ${f.min}`;
        else if (f.max !== undefined && n > f.max) errors[f.key] = `Не больше ${f.max}`;
        else if (['year', 'founded'].includes(f.key) && !Number.isInteger(n)) errors[f.key] = 'Введите целый год';
      }
      if (f.format && !FORMATS[f.format][0].test(v)) errors[f.key] = FORMATS[f.format][1];
    });
    // Уникальность
    if (entity === 'companies' && values.name && !errors.name) {
      const dup = state.companies.some(c => c.id !== editingId && c.name.toLowerCase() === values.name.toLowerCase());
      if (dup) errors.name = 'Компания с таким названием уже есть';
    }
    if (entity === 'stats' && values.year && !errors.year) {
      const dup = state.stats.some(s => s.id !== editingId && num(s.year) === Number(values.year));
      if (dup) errors.year = 'Данные за этот год уже внесены';
    }
    return errors;
  }

  function showErrors(form, errors) {
    $$('.field', form).forEach(box => {
      const msg = errors[box.dataset.field];
      box.classList.toggle('invalid', !!msg);
      $('.error', box).textContent = msg || '';
    });
    const first = Object.keys(errors)[0];
    if (first && form.elements[first]) form.elements[first].focus();
  }

  function normalize(entity, values, fields) {
    const out = {};
    fields.forEach(f => {
      out[f.key] = f.type === 'number' ? (values[f.key] === '' ? 0 : Number(values[f.key])) : values[f.key];
    });
    if (entity === 'companies' && out.website && !/^https?:\/\//i.test(out.website)) out.website = 'https://' + out.website;
    return out;
  }

  /* ---------------------------------------------------------
   * 7. Добавление / редактирование / удаление
   * --------------------------------------------------------- */
  let modalCtx = null; // { entity, id }
  const modal = $('#modal');
  const modalForm = $('#modalForm');

  function openModal(entity, id = null) {
    const cfg = ENTITIES[entity];
    const record = id ? state[entity].find(r => r.id === id) : null;
    if (id && !record) return;
    const values = record || cfg.defaults();
    modalCtx = { entity, id };
    $('#modalTitle').textContent = record ? cfg.editTitle : cfg.addTitle;
    $('#modalFields').innerHTML = cfg.fields.map(f => fieldHTML(f, values[f.key], 'm')).join('');
    modal.showModal();
  }

  function closeModal() { if (modal.open) modal.close(); modalCtx = null; }

  modalForm.addEventListener('submit', e => {
    e.preventDefault();
    if (!modalCtx) return;
    const { entity, id } = modalCtx;
    const cfg = ENTITIES[entity];
    const values = readForm(modalForm, cfg.fields);
    const errors = validate(entity, values, cfg.fields, id);
    showErrors(modalForm, errors);
    if (Object.keys(errors).length) return;

    const data = normalize(entity, values, cfg.fields);
    if (id) {
      const rec = state[entity].find(r => r.id === id);
      const oldName = rec.name;
      Object.assign(rec, data);
      // при переименовании компании обновляем связанные продукты
      if (entity === 'companies' && oldName !== rec.name) {
        state.products.forEach(p => { if (p.company === oldName) p.company = rec.name; });
      }
      toast('Изменения сохранены');
    } else {
      state[entity].push({ id: uid(), demo: false, ...data });
      toast('Запись добавлена');
    }
    saveState();
    closeModal();
    refresh();
  });

  $('#modalClose').addEventListener('click', closeModal);
  $('#modalCancel').addEventListener('click', closeModal);
  modal.addEventListener('click', e => { if (e.target === modal) closeModal(); });

  function deleteRecord(entity, id) {
    const rec = state[entity].find(r => r.id === id);
    if (!rec) return;
    if (!confirm(`Удалить «${ENTITIES[entity].nameOf(rec)}»? Действие нельзя отменить.`)) return;
    state[entity] = state[entity].filter(r => r.id !== id);
    saveState();
    refresh();
    toast('Запись удалена');
  }

  /* ---------------------------------------------------------
   * 8. Регистрация компании
   * --------------------------------------------------------- */
  const regForm = $('#regForm');
  const REG_FIELDS = ENTITIES.companies.fields.filter(f => !f.onlyModal);

  function renderRegForm() {
    $('#regFields').innerHTML = REG_FIELDS.map(f =>
      fieldHTML(f, f.key === 'founded' ? new Date().getFullYear() : '', 'r')).join('');
    $('#regAgreeErr').textContent = '';
  }

  regForm.addEventListener('submit', e => {
    e.preventDefault();
    const values = readForm(regForm, REG_FIELDS);
    const errors = validate('companies', values, REG_FIELDS, null);
    showErrors(regForm, errors);
    const agree = $('#regAgree').checked;
    $('#regAgreeErr').textContent = agree ? '' : 'Необходимо подтвердить достоверность данных';
    if (Object.keys(errors).length || !agree) return;

    const data = normalize('companies', values, REG_FIELDS);
    state.companies.push({ id: uid(), demo: false, status: 'На модерации', ...data });
    saveState();
    regForm.reset();
    renderRegForm();
    refresh();
    toast('Компания зарегистрирована и отправлена на модерацию');
    location.hash = '#companies';
  });

  regForm.addEventListener('reset', () => setTimeout(renderRegForm, 0));

  /* ---------------------------------------------------------
   * 9. Экспорт CSV
   * --------------------------------------------------------- */
  function toCSV(headers, rows) {
    const cell = v => {
      let s = typeof v === 'number' ? String(v).replace('.', ',') : String(v ?? '');
      if (typeof v === 'string' && /^[=+\-@]/.test(s)) s = "'" + s; // защита от формул Excel
      return '"' + s.replace(/"/g, '""') + '"';
    };
    return [headers, ...rows].map(r => r.map(cell).join(';')).join('\r\n');
  }

  function download(name, csv) {
    const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `ikt-kg-${name}-${new Date().toISOString().slice(0, 10)}.csv`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 500);
    toast('Файл CSV сформирован');
  }

  const demoCol = r => r.demo ? 'да' : 'нет';

  function exportEntity(entity, useFilters) {
    if (entity === 'companies') {
      const list = useFilters ? getFilteredCompanies() : state.companies;
      download('companies', toCSV(
        ['Название', 'Направление', 'Город', 'Год основания', 'Сотрудники', 'Выручка, млн сом', 'Услуги', 'Сайт', 'E-mail', 'Телефон', 'Контактное лицо', 'Статус', 'Демо-данные'],
        list.map(c => [c.name, c.category, c.city, c.founded, c.employees, c.revenue, c.services, c.website, c.email, c.phone, c.contact, c.status, demoCol(c)])));
    } else if (entity === 'products') {
      const list = useFilters ? getFilteredProducts() : state.products;
      download('products', toCSV(
        ['Название', 'Тип', 'Компания', 'Цена, сом', 'Единица', 'Описание', 'Демо-данные'],
        list.map(p => [p.name, p.type, p.company, p.price, p.unit, p.description, demoCol(p)])));
    } else if (entity === 'stats') {
      download('statistics', toCSV(
        ['Год', 'Объём рынка, млрд сом', 'Доля в ВВП, %', 'Экспорт ИКТ-услуг, млн USD', 'Занятые, тыс. чел.', 'Пользователи интернета, %', 'Демо-данные'],
        sortedStats().map(s => [s.year, s.marketVolume, s.gdpShare, s.exportUsd, s.employed, s.internet, demoCol(s)])));
    }
  }

  function exportSummary(kind) {
    if (kind === 'directions') {
      download('directions', toCSV(
        ['Направление', 'Компаний', 'Сотрудники', 'Выручка, млн сом', 'Средняя выручка, млн сом'],
        directionRows().map(r => [r.name, r.count, r.employees, r.revenue, Number(r.avg.toFixed(1))])));
    } else if (kind === 'prices') {
      download('prices', toCSV(
        ['Тип', 'Позиций', 'Мин. цена, сом', 'Средняя цена, сом', 'Макс. цена, сом'],
        priceRows().map(r => [r.name, r.count, r.min, Math.round(r.avg), r.max])));
    } else if (kind === 'cities') {
      download('cities', toCSV(
        ['Город', 'Компаний', 'Сотрудники', 'Выручка, млн сом'],
        cityRows().map(r => [r.name, r.count, r.employees, r.revenue])));
    }
  }

  /* ---------------------------------------------------------
   * 10. Агрегирование данных
   * --------------------------------------------------------- */
  const sortedStats = () => [...state.stats].sort((a, b) => num(a.year) - num(b.year));

  function directionRows() {
    const g = groupBy(state.companies, c => c.category);
    return CATEGORIES.filter(k => g.has(k)).map(k => {
      const items = g.get(k);
      const revenue = sum(items, 'revenue');
      return { name: k, count: items.length, employees: sum(items, 'employees'), revenue, avg: revenue / items.length };
    }).sort((a, b) => b.revenue - a.revenue);
  }

  function cityRows() {
    const g = groupBy(state.companies, c => c.city);
    return [...g.entries()].map(([name, items]) => ({
      name, count: items.length, employees: sum(items, 'employees'), revenue: sum(items, 'revenue')
    })).sort((a, b) => b.count - a.count || b.revenue - a.revenue);
  }

  function priceRows() {
    const g = groupBy(state.products, p => p.type);
    return PRODUCT_TYPES.filter(k => g.has(k)).map(k => {
      const prices = g.get(k).map(p => num(p.price));
      return { name: k, count: prices.length, min: Math.min(...prices), max: Math.max(...prices), avg: prices.reduce((a, b) => a + b, 0) / prices.length };
    });
  }

  /* ---------------------------------------------------------
   * 11. Отрисовка таблиц и карточек
   * --------------------------------------------------------- */
  const statusBadge = s => {
    const cls = s === 'Активна' ? 'ok' : s === 'На модерации' ? 'warn' : 'off';
    return `<span class="badge badge--${cls}">${esc(s)}</span>`;
  };

  const actionBtns = (entity, id) => `
    <button class="icon-btn" title="Редактировать" aria-label="Редактировать" data-action="edit" data-entity="${entity}" data-id="${id}">✎</button>
    <button class="icon-btn del" title="Удалить" aria-label="Удалить" data-action="delete" data-entity="${entity}" data-id="${id}">🗑</button>`;

  const emptyRow = (cols, text = 'Ничего не найдено') =>
    `<tbody><tr><td colspan="${cols}" class="empty">${text}</td></tr></tbody>`;

  function kpi(cls, icon, label, value, sub = '') {
    return `<article class="kpi ${cls}"><div class="kpi__icon">${icon}</div><div>
      <span class="kpi__label">${label}</span><strong class="kpi__value">${value}</strong>
      <span class="kpi__sub">${sub}</span></div></article>`;
  }

  function renderDashboard() {
    const stats = sortedStats();
    const last = stats[stats.length - 1];
    const prev = stats[stats.length - 2];
    const growth = last && prev && num(prev.marketVolume) ? (last.marketVolume / prev.marketVolume - 1) * 100 : null;
    const active = state.companies.filter(c => c.status === 'Активна').length;

    $('#kpiGrid').innerHTML = [
      kpi('', '🏢', 'IT-компаний в каталоге', fmt(state.companies.length), `активных: ${fmt(active)}`),
      kpi('kpi--blue', '👥', 'Сотрудников в компаниях', fmt(sum(state.companies, 'employees'))),
      kpi('kpi--deep', '💰', 'Суммарная выручка, млн сом', fmt(sum(state.companies, 'revenue'), 1)),
      kpi('kpi--lime', '💻', 'Услуг и продуктов', fmt(state.products.length)),
      kpi('kpi--blue', '📈', last ? `Объём рынка ИКТ, ${last.year} г.` : 'Объём рынка ИКТ',
          last ? fmt(last.marketVolume, 1) + ' млрд сом' : '—',
          growth !== null ? `${growth >= 0 ? '▲' : '▼'} ${fmt(Math.abs(growth), 1)}% к ${prev.year} г. (демо)` : 'демо'),
      kpi('', '🏛', 'Доля ИКТ в ВВП', last ? fmt(last.gdpShare, 1) + ' %' : '—', 'демонстрационное значение')
    ].join('');

    const top = [...state.companies].sort((a, b) => num(b.revenue) - num(a.revenue)).slice(0, 5);
    $('#topTable').innerHTML = `<thead><tr><th>#</th><th>Компания</th><th>Направление</th><th>Город</th>
      <th class="num">Сотрудники</th><th class="num">Выручка, млн сом</th></tr></thead>` +
      (top.length ? `<tbody>${top.map((c, i) => `<tr><td>${i + 1}</td><td><strong>${esc(c.name)}</strong>${demoTag(c)}</td>
        <td>${esc(c.category)}</td><td>${esc(c.city)}</td><td class="num">${fmt(c.employees)}</td>
        <td class="num">${fmt(c.revenue, 1)}</td></tr>`).join('')}</tbody>` : emptyRow(6, 'Нет данных'));
  }

  function getFilteredCompanies() {
    const q = $('#companySearch').value.trim().toLowerCase();
    const cat = $('#companyCategory').value;
    const city = $('#companyCity').value;
    const st = $('#companyStatus').value;
    const sort = $('#companySort').value;
    const sorters = {
      name: (a, b) => a.name.localeCompare(b.name, 'ru'),
      revenue: (a, b) => num(b.revenue) - num(a.revenue),
      employees: (a, b) => num(b.employees) - num(a.employees),
      founded: (a, b) => num(b.founded) - num(a.founded)
    };
    return state.companies.filter(c => {
      const hay = [c.name, c.services, c.city, c.category, c.contact].join(' ').toLowerCase();
      return (!q || hay.includes(q)) && (!cat || c.category === cat) && (!city || c.city === city) && (!st || c.status === st);
    }).sort(sorters[sort] || sorters.name);
  }

  function renderCompanies() {
    const list = getFilteredCompanies();
    $('#companyCount').textContent = `Найдено: ${list.length} из ${state.companies.length}`;
    $('#companiesTable').innerHTML = `<thead><tr><th>Компания</th><th>Направление</th><th>Город</th>
      <th class="num">Основана</th><th class="num">Сотрудники</th><th class="num">Выручка, млн сом</th>
      <th>Услуги</th><th>Статус</th><th></th></tr></thead>` +
      (list.length ? `<tbody>${list.map(c => `<tr>
        <td><strong>${esc(c.name)}</strong>${demoTag(c)}${c.website ? `<br><a href="${esc(c.website)}" target="_blank" rel="noopener noreferrer">${esc(c.website.replace(/^https?:\/\//, ''))}</a>` : ''}</td>
        <td>${esc(c.category)}</td><td>${esc(c.city)}</td><td class="num">${esc(c.founded)}</td>
        <td class="num">${fmt(c.employees)}</td><td class="num">${fmt(c.revenue, 1)}</td>
        <td class="clip">${esc(c.services)}</td><td>${statusBadge(c.status)}</td>
        <td class="actions">${actionBtns('companies', c.id)}</td></tr>`).join('')}</tbody>` : emptyRow(9));
  }

  function getFilteredProducts() {
    const q = $('#productSearch').value.trim().toLowerCase();
    const type = $('#productType').value;
    const sort = $('#productSort').value;
    const sorters = {
      name: (a, b) => a.name.localeCompare(b.name, 'ru'),
      'price-asc': (a, b) => num(a.price) - num(b.price),
      'price-desc': (a, b) => num(b.price) - num(a.price)
    };
    return state.products.filter(p => {
      const hay = [p.name, p.company, p.description, p.type].join(' ').toLowerCase();
      return (!q || hay.includes(q)) && (!type || p.type === type);
    }).sort(sorters[sort] || sorters.name);
  }

  function renderProducts() {
    const rows = priceRows();
    const icons = { 'IT-услуга': '🛠', 'Программное обеспечение': '🧩', 'Цифровой продукт': '📦' };
    const cls = { 'IT-услуга': '', 'Программное обеспечение': 'kpi--blue', 'Цифровой продукт': 'kpi--deep' };
    $('#productTypeCards').innerHTML = PRODUCT_TYPES.map(t => {
      const r = rows.find(x => x.name === t);
      return kpi(cls[t], icons[t], t, r ? fmt(r.count) + ' поз.' : '0 поз.', r ? `средняя цена: ${fmt(r.avg)} сом` : 'нет данных');
    }).join('');

    const list = getFilteredProducts();
    $('#productCount').textContent = `Найдено: ${list.length} из ${state.products.length}`;
    $('#productsTable').innerHTML = `<thead><tr><th>Название</th><th>Тип</th><th>Компания</th>
      <th class="num">Цена, сом</th><th>Единица</th><th>Описание</th><th></th></tr></thead>` +
      (list.length ? `<tbody>${list.map(p => `<tr>
        <td><strong>${esc(p.name)}</strong>${demoTag(p)}</td>
        <td><span class="badge badge--type">${esc(p.type)}</span></td><td>${esc(p.company)}</td>
        <td class="num">${fmt(p.price, 2)}</td><td>${esc(p.unit)}</td><td class="clip">${esc(p.description)}</td>
        <td class="actions">${actionBtns('products', p.id)}</td></tr>`).join('')}</tbody>` : emptyRow(7));
  }

  function renderSummaryTables() {
    const dir = directionRows();
    $('#directionsTable').innerHTML = `<thead><tr><th>Направление</th><th class="num">Компаний</th>
      <th class="num">Сотрудники</th><th class="num">Выручка, млн сом</th><th class="num">Средняя выручка, млн сом</th></tr></thead>` +
      (dir.length ? `<tbody>${dir.map(r => `<tr><td>${esc(r.name)}</td><td class="num">${fmt(r.count)}</td>
        <td class="num">${fmt(r.employees)}</td><td class="num">${fmt(r.revenue, 1)}</td><td class="num">${fmt(r.avg, 1)}</td></tr>`).join('')}</tbody>
        <tfoot><tr><td>Итого</td><td class="num">${fmt(sum(dir, 'count'))}</td><td class="num">${fmt(sum(dir, 'employees'))}</td>
        <td class="num">${fmt(sum(dir, 'revenue'), 1)}</td><td></td></tr></tfoot>` : emptyRow(5, 'Нет данных'));

    const pr = priceRows();
    $('#pricesTable').innerHTML = `<thead><tr><th>Тип</th><th class="num">Позиций</th><th class="num">Мин. цена, сом</th>
      <th class="num">Средняя цена, сом</th><th class="num">Макс. цена, сом</th></tr></thead>` +
      (pr.length ? `<tbody>${pr.map(r => `<tr><td>${esc(r.name)}</td><td class="num">${fmt(r.count)}</td>
        <td class="num">${fmt(r.min)}</td><td class="num">${fmt(r.avg)}</td><td class="num">${fmt(r.max)}</td></tr>`).join('')}</tbody>` : emptyRow(5, 'Нет данных'));

    const ct = cityRows();
    $('#citiesTable').innerHTML = `<thead><tr><th>Город</th><th class="num">Компаний</th><th class="num">Сотрудники</th>
      <th class="num">Выручка, млн сом</th></tr></thead>` +
      (ct.length ? `<tbody>${ct.map(r => `<tr><td>${esc(r.name)}</td><td class="num">${fmt(r.count)}</td>
        <td class="num">${fmt(r.employees)}</td><td class="num">${fmt(r.revenue, 1)}</td></tr>`).join('')}</tbody>` : emptyRow(4, 'Нет данных'));
  }

  function growthPct(cur, prev) {
    return prev && num(prev) ? (num(cur) / num(prev) - 1) * 100 : null;
  }

  function renderStatistics() {
    const st = sortedStats();
    const first = st[0], last = st[st.length - 1], prev = st[st.length - 2];
    if (last) {
      const years = num(last.year) - num(first.year);
      const cagr = years > 0 && num(first.marketVolume) > 0 ? (Math.pow(last.marketVolume / first.marketVolume, 1 / years) - 1) * 100 : null;
      const g = prev ? growthPct(last.marketVolume, prev.marketVolume) : null;
      $('#statKpis').innerHTML = [
        kpi('', '📈', `Объём рынка, ${last.year} г.`, fmt(last.marketVolume, 1) + ' млрд сом', g !== null ? `${g >= 0 ? '▲' : '▼'} ${fmt(Math.abs(g), 1)}% за год` : ''),
        kpi('kpi--blue', '🚀', `Среднегодовой рост ${first.year}–${last.year}`, cagr !== null ? fmt(cagr, 1) + ' %' : '—', 'CAGR объёма рынка'),
        kpi('kpi--deep', '🌍', 'Экспорт ИКТ-услуг', fmt(last.exportUsd, 1) + ' млн USD', `в ${last.year} г.`),
        kpi('kpi--lime', '👩‍💻', 'Занятые в ИКТ', fmt(last.employed, 1) + ' тыс.', `интернетом пользуются ${fmt(last.internet, 1)}%`)
      ].join('');
    } else {
      $('#statKpis').innerHTML = '';
    }

    $('#statsTable').innerHTML = `<thead><tr><th>Год</th><th class="num">Объём рынка, млрд сом</th><th class="num">Рост к пред. году</th>
      <th class="num">Доля в ВВП, %</th><th class="num">Экспорт, млн USD</th><th class="num">Занятые, тыс.</th>
      <th class="num">Интернет, %</th><th></th></tr></thead>` +
      (st.length ? `<tbody>${[...st].reverse().map(s => {
        const idx = st.indexOf(s);
        const g = idx > 0 ? growthPct(s.marketVolume, st[idx - 1].marketVolume) : null;
        return `<tr><td><strong>${esc(s.year)}</strong>${demoTag(s)}</td><td class="num">${fmt(s.marketVolume, 1)}</td>
          <td class="num ${g === null ? '' : g >= 0 ? 'up' : 'down'}">${g === null ? '—' : (g >= 0 ? '+' : '') + fmt(g, 1) + '%'}</td>
          <td class="num">${fmt(s.gdpShare, 1)}</td><td class="num">${fmt(s.exportUsd, 1)}</td>
          <td class="num">${fmt(s.employed, 1)}</td><td class="num">${fmt(s.internet, 1)}</td>
          <td class="actions">${actionBtns('stats', s.id)}</td></tr>`;
      }).join('')}</tbody>` : emptyRow(8, 'Нет данных'));
  }

  function renderStorageInfo() {
    let size = 0;
    try { size = (localStorage.getItem(STORAGE_KEY) || '').length; } catch (e) { /* ignore */ }
    const demoCount = [...state.companies, ...state.products, ...state.stats].filter(r => r.demo).length;
    const ownCount = state.companies.length + state.products.length + state.stats.length - demoCount;
    $('#storageInfo').innerHTML = `
      <div><strong>${fmt(state.companies.length)}</strong>компаний</div>
      <div><strong>${fmt(state.products.length)}</strong>услуг и продуктов</div>
      <div><strong>${fmt(state.stats.length)}</strong>лет статистики</div>
      <div><strong>${fmt(demoCount)} / ${fmt(ownCount)}</strong>демо / ваших записей</div>
      <div><strong>${fmt(size / 1024, 1)} КБ</strong>занято в localStorage</div>`;
  }

  /* ---------------------------------------------------------
   * 12. Графики Chart.js
   * --------------------------------------------------------- */
  const charts = {};

  function draw(id, type, data, options = {}) {
    const el = document.getElementById(id);
    if (!el) return;
    if (typeof Chart === 'undefined') {
      el.parentElement.innerHTML = '<p class="empty">Не удалось загрузить Chart.js. Проверьте подключение к интернету.</p>';
      return;
    }
    if (charts[id]) charts[id].destroy();
    const base = { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom' } } };
    charts[id] = new Chart(el, { type, data, options: { ...base, ...options } });
  }

  const noLegend = { legend: { display: false } };
  const axisTitle = text => ({ title: { display: true, text } });

  function drawDashboardCharts() {
    const dir = directionRows();
    draw('ch_dash_cat', 'doughnut', {
      labels: dir.map(r => r.name),
      datasets: [{ data: dir.map(r => r.count), backgroundColor: PALETTE, borderWidth: 2, borderColor: '#fff' }]
    });
    const st = sortedStats();
    draw('ch_dash_market', 'line', {
      labels: st.map(s => s.year),
      datasets: [{ label: 'Объём рынка, млрд сом', data: st.map(s => num(s.marketVolume)), borderColor: '#0e8f9a',
        backgroundColor: 'rgba(15,157,110,.18)', fill: true, tension: .3, pointRadius: 4 }]
    }, { plugins: noLegend });
  }

  function drawAnalyticsCharts() {
    const dir = directionRows();
    draw('ch_cat_rev', 'bar', {
      labels: dir.map(r => r.name),
      datasets: [{ label: 'Выручка, млн сом', data: dir.map(r => r.revenue), backgroundColor: PALETTE, borderRadius: 6 }]
    }, { plugins: noLegend, scales: { x: { ticks: { maxRotation: 40, minRotation: 0 } } } });

    const ct = cityRows();
    draw('ch_city', 'pie', {
      labels: ct.map(r => r.name),
      datasets: [{ data: ct.map(r => r.count), backgroundColor: PALETTE, borderWidth: 2, borderColor: '#fff' }]
    });

    const emp = [...state.companies].sort((a, b) => num(b.employees) - num(a.employees)).slice(0, 8);
    draw('ch_emp', 'bar', {
      labels: emp.map(c => c.name),
      datasets: [{ label: 'Сотрудники', data: emp.map(c => num(c.employees)), backgroundColor: '#1b6ec2', borderRadius: 6 }]
    }, { indexAxis: 'y', plugins: noLegend });

    const pr = priceRows();
    draw('ch_price', 'bar', {
      labels: pr.map(r => r.name),
      datasets: [{ label: 'Средняя цена, сом', data: pr.map(r => Math.round(r.avg)), backgroundColor: ['#0f9d6e', '#0e8f9a', '#1b6ec2'], borderRadius: 6 }]
    }, { plugins: noLegend });

    const byYear = [...groupBy(state.companies, c => num(c.founded)).entries()].sort((a, b) => a[0] - b[0]);
    let total = 0;
    draw('ch_founded', 'line', {
      labels: byYear.map(([y]) => y),
      datasets: [{ label: 'Компаний всего (нарастающим итогом)', data: byYear.map(([, items]) => (total += items.length)),
        borderColor: '#0f9d6e', backgroundColor: 'rgba(14,143,154,.18)', fill: true, stepped: true, pointRadius: 4 }]
    }, { plugins: noLegend });

    draw('ch_scatter', 'scatter', {
      datasets: [{ label: 'Компании', backgroundColor: 'rgba(27,110,194,.75)', pointRadius: 7,
        data: state.companies.map(c => ({ x: num(c.employees), y: num(c.revenue), name: c.name })) }]
    }, {
      plugins: {
        legend: { display: false },
        tooltip: { callbacks: { label: ctx => `${ctx.raw.name}: ${fmt(ctx.raw.x)} сотр., ${fmt(ctx.raw.y, 1)} млн сом` } }
      },
      scales: { x: axisTitle('Сотрудники'), y: axisTitle('Выручка, млн сом') }
    });
  }

  function drawStatisticsCharts() {
    const st = sortedStats();
    const labels = st.map(s => s.year);
    draw('ch_st_market', 'bar', {
      labels,
      datasets: [
        { type: 'bar', label: 'Объём рынка, млрд сом', data: st.map(s => num(s.marketVolume)), backgroundColor: '#0e8f9a', borderRadius: 6, yAxisID: 'y' },
        { type: 'line', label: 'Доля в ВВП, %', data: st.map(s => num(s.gdpShare)), borderColor: '#0f9d6e', backgroundColor: '#0f9d6e', tension: .3, yAxisID: 'y1' }
      ]
    }, { scales: { y: axisTitle('млрд сом'), y1: { position: 'right', grid: { drawOnChartArea: false }, ...axisTitle('% ВВП') } } });

    draw('ch_st_export', 'line', {
      labels,
      datasets: [
        { label: 'Экспорт, млн USD', data: st.map(s => num(s.exportUsd)), borderColor: '#1b6ec2', backgroundColor: '#1b6ec2', tension: .3, yAxisID: 'y' },
        { label: 'Занятые, тыс. чел.', data: st.map(s => num(s.employed)), borderColor: '#6cc24a', backgroundColor: '#6cc24a', tension: .3, yAxisID: 'y1' }
      ]
    }, { scales: { y: axisTitle('млн USD'), y1: { position: 'right', grid: { drawOnChartArea: false }, ...axisTitle('тыс. чел.') } } });

    draw('ch_st_internet', 'line', {
      labels,
      datasets: [{ label: 'Пользователи интернета, %', data: st.map(s => num(s.internet)), borderColor: '#0e8f9a',
        backgroundColor: 'rgba(14,143,154,.2)', fill: true, tension: .3, pointRadius: 4 }]
    }, { plugins: noLegend, scales: { y: { min: 0, max: 100 } } });

    const growth = st.map((s, i) => i ? growthPct(s.marketVolume, st[i - 1].marketVolume) : null);
    draw('ch_st_growth', 'bar', {
      labels,
      datasets: [{ label: 'Прирост, %', data: growth.map(g => g === null ? null : Number(g.toFixed(1))),
        backgroundColor: growth.map(g => (g ?? 0) >= 0 ? '#0f9d6e' : '#d64545'), borderRadius: 6 }]
    }, { plugins: noLegend });
  }

  const CHART_DRAWERS = {
    dashboard: drawDashboardCharts,
    charts: drawAnalyticsCharts,
    statistics: drawStatisticsCharts
  };

  /* ---------------------------------------------------------
   * 13. Навигация
   * --------------------------------------------------------- */
  const TITLES = {
    dashboard: 'Главная панель', companies: 'Каталог IT-компаний', products: 'IT-услуги, ПО и цифровые продукты',
    tables: 'Сводные таблицы', charts: 'Аналитика рынка', statistics: 'Статистика и динамика развития ИКТ',
    register: 'Регистрация IT-компании', data: 'Данные и экспорт'
  };
  let currentSection = 'dashboard';

  function showSection(id) {
    if (!TITLES[id]) id = 'dashboard';
    currentSection = id;
    $$('.view').forEach(v => v.classList.toggle('active', v.id === id));
    $$('#nav a').forEach(a => a.classList.toggle('active', a.dataset.section === id));
    $('#pageTitle').textContent = TITLES[id];
    document.title = `${TITLES[id]} — Рынок ИКТ Кыргызстана`;
    closeSidebar();
    window.scrollTo({ top: 0 });
    drawCurrentCharts();
  }

  function drawCurrentCharts() {
    const fn = CHART_DRAWERS[currentSection];
    if (fn) fn();
  }

  const sidebar = $('#sidebar');
  const closeSidebar = () => sidebar.classList.remove('open');
  $('#burger').addEventListener('click', () => sidebar.classList.toggle('open'));
  $('#overlay').addEventListener('click', closeSidebar);
  window.addEventListener('hashchange', () => showSection(location.hash.slice(1)));

  /* ---------------------------------------------------------
   * 14. Общее обновление интерфейса
   * --------------------------------------------------------- */
  function refresh() {
    renderDashboard();
    renderCompanies();
    renderProducts();
    renderSummaryTables();
    renderStatistics();
    renderStorageInfo();
    drawCurrentCharts();
  }

  /* ---------------------------------------------------------
   * 15. Обработчики событий
   * --------------------------------------------------------- */
  function fillSelect(sel, placeholder, options) {
    sel.innerHTML = `<option value="">${esc(placeholder)}</option>` +
      options.map(o => `<option value="${esc(o)}">${esc(o)}</option>`).join('');
  }

  function resetFilters(entity) {
    if (entity === 'companies') {
      $('#companySearch').value = '';
      ['#companyCategory', '#companyCity', '#companyStatus'].forEach(s => { $(s).value = ''; });
      $('#companySort').value = 'name';
      renderCompanies();
    } else {
      $('#productSearch').value = '';
      $('#productType').value = '';
      $('#productSort').value = 'name';
      renderProducts();
    }
  }

  document.addEventListener('click', e => {
    const btn = e.target.closest('[data-action]');
    if (!btn) return;
    const { action, entity, id } = btn.dataset;
    switch (action) {
      case 'add': openModal(entity); break;
      case 'edit': openModal(entity, id); break;
      case 'delete': deleteRecord(entity, id); break;
      case 'export': exportEntity(entity, true); break;
      case 'export-all': exportEntity(entity, false); break;
      case 'export-summary': exportSummary(entity); break;
      case 'reset-filters': resetFilters(entity); break;
      case 'reset-demo':
        if (confirm('Все текущие данные будут заменены демонстрационными. Продолжить?')) {
          state = seedData(); saveState(); refresh(); toast('Демо-данные восстановлены');
        }
        break;
      case 'clear-all':
        if (confirm('Удалить ВСЕ данные (компании, услуги и статистику)? Действие нельзя отменить.')) {
          state = { companies: [], products: [], stats: [] }; saveState(); refresh(); toast('Все данные удалены');
        }
        break;
    }
  });

  ['#companySearch', '#companyCategory', '#companyCity', '#companyStatus', '#companySort']
    .forEach(s => $(s).addEventListener('input', renderCompanies));
  ['#productSearch', '#productType', '#productSort']
    .forEach(s => $(s).addEventListener('input', renderProducts));

  /* ---------------------------------------------------------
   * 16. Запуск
   * --------------------------------------------------------- */
  function init() {
    loadState();
    fillSelect($('#companyCategory'), 'Все направления', CATEGORIES);
    fillSelect($('#companyCity'), 'Все города', CITIES);
    fillSelect($('#companyStatus'), 'Все статусы', STATUSES);
    fillSelect($('#productType'), 'Все типы', PRODUCT_TYPES);
    renderRegForm();
    refresh();
    showSection(location.hash.slice(1) || 'dashboard');
  }

  // Скрипт подключён с defer, DOM уже готов
  init();
})();
